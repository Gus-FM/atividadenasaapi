import express from "express";
import axios from "axios";
import path from "path";
import { fileURLToPath } from "url";

const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NASA_KEY =
    "9v8RutEyFArrQuSZX7SoNsLwk0BEZ7LVPBhgo98k";

app.set("view engine", "ejs");

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
    res.render("index");
});

app.post("/search", async (req, res) => {
    try {
        const astro = req.body.astro;

        const { data } = await axios.get(
            "https://images-api.nasa.gov/search",
            {
                params: {
                    q: astro,
                    media_type: "image"
                }
            }
        );

        const images =
            data.collection.items
                .filter(item => item.links)
                .map(item => ({
                    title:
                        item.data[0]?.title ||
                        "Sem título",

                    description:
                        item.data[0]?.description ||
                        "",

                    url:
                        item.links[0]?.href
                }));

        res.render("results", {
            astro,
            images
        });

    } catch (error) {

        console.error(error);

        res.render("results", {
            astro: "",
            images: []
        });

    }
});
const PORT = 3000;

app.listen(PORT, () => {
    console.log(
        `Servidor rodando em http://localhost:${PORT}`
    );
});